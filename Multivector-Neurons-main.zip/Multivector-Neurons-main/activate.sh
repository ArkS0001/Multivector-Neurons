# export WANDB_ENTITY=
export WANDB_PROJECT=mvn
export PROJECT_DIR=~/Multivector-Neurons

export DATAROOT=~/Multivector-Neurons/datasets/
source ~/miniconda3/bin/activate
conda activate mvn